// Ловит URL HLS-плейлистов видео (вкладка Media в DevTools их не показывает).
//
// Важно: service worker в MV3 выгружается после ~30 с простоя, и обычная Map
// при этом теряется. Поэтому пойманные ссылки лежат в chrome.storage.session —
// они переживают перезапуск воркера и живут до закрытия браузера.
const KEY = "playlists"; // tabId -> [{url, ts}]
const UPD_KEY = "update";   // последняя найденная новая версия

// Общие функции (сравнение версий, запрос ленты обновлений) — из core.js,
// чтобы воркер и страницы считали версии одинаково.
importScripts("core.js");

/* ---------- Проверка обновлений в фоне ----------
   Chrome не умеет обновлять распакованное расширение сам, но пользователь
   должен УЗНАТЬ о новой версии. Поэтому воркер:
     - по расписанию (раз в час) спрашивает ленту обновлений;
     - пишет результат в chrome.storage.local;
     - ставит значок на иконке расширения ("1.6"), чтобы обновление было
       видно БЕЗ открытия попапа.
   Значок снимается, когда пользователь обновился (версия совпала). */
const UPD_ALARM = "yadisk-update-check";

async function refreshUpdateBadge() {
  let info = null;
  try { info = await fetchUpdateInfo(); } catch (e) { info = null; }
  await chrome.storage.local.set({ [UPD_KEY]: info || null });
  try {
    if (info) {
      // короткая метка: Chrome показывает максимум ~4 символа
      const short = info.version.split(".").slice(0, 2).join(".");
      await chrome.action.setBadgeText({ text: short });
      await chrome.action.setBadgeBackgroundColor({ color: "#2f9e44" });
      await chrome.action.setTitle({
        title: `YaDisk Saver: доступна версия ${info.version} (у вас ${currentVersion()})`,
      });
    } else {
      await chrome.action.setBadgeText({ text: "" });
      await chrome.action.setTitle({ title: "YaDisk Saver" });
    }
  } catch (e) { /* значок не критичен */ }
  return info;
}

function setupUpdateAlarm() {
  try {
    chrome.alarms.create(UPD_ALARM, { periodInMinutes: 60, delayInMinutes: 1 });
  } catch (e) { /* alarms может быть недоступен */ }
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === UPD_ALARM) refreshUpdateBadge();
});

chrome.runtime.onInstalled.addListener(() => {
  setupUpdateAlarm();
  refreshUpdateBadge();
});

chrome.runtime.onStartup.addListener(() => {
  setupUpdateAlarm();
  refreshUpdateBadge();
});

// сразу при загрузке воркера
setupUpdateAlarm();
refreshUpdateBadge();

// ВАЖНО: blob-URL отзываются в самой странице (grab/batch), а не здесь.
// В service worker этого метода нет — он даёт TypeError.
// Страница подписывается на chrome.downloads.onChanged сама.

function readAll() {
  return chrome.storage.session.get(KEY).then((r) => r[KEY] || {});
}
function writeAll(map) {
  return chrome.storage.session.set({ [KEY]: map });
}

// Запросы m3u8 приходят ПАРАЛЛЕЛЬНО (мастер + вариант грузятся одновременно).
// Без очереди readAll->writeAll не атомарен: второй запрос успевал записать
// карту поверх первого, и один из плейлистов терялся -> «поток не пойман».
let writeQueue = Promise.resolve();

async function remember(tabId, url) {
  writeQueue = writeQueue.then(async () => {
    const map = await readAll();
    const arr = (map[tabId] || []).filter((e) => e.url !== url);
    arr.push({ url, ts: Date.now() });
    map[tabId] = arr.slice(-20);
    await writeAll(map);
  }).catch(() => { /* очередь не должна рваться из-за одной ошибки */ });
  await writeQueue;
}

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const u = details.url;
    if (!u.includes("streaming.disk.yandex.net")) return;
    if (!u.includes("m3u8")) return; // сегменты .ts сюда не попадают
    remember(details.tabId, u);
  },
  { urls: ["*://streaming.disk.yandex.net/*"] }
);

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const map = await readAll();
  delete map[tabId];
  await writeAll(map);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "getPlaylists") {
    // отдаём по конкретной вкладке; tabId=null/-1 -> всё, что поймали
    readAll().then((map) => {
      const items = (typeof msg.tabId === "number" && msg.tabId >= 0)
        ? (map[msg.tabId] || [])
        : Object.values(map).flat();
      sendResponse({ items });
    });
    return true;
  }
  if (msg.type === "clearPlaylists") {
    readAll().then(async (map) => {
      if (typeof msg.tabId === "number" && msg.tabId >= 0) delete map[msg.tabId];
      else Object.keys(map).forEach((k) => delete map[k]);
      await writeAll(map);
      sendResponse({ ok: true });
    });
    return true;
  }
  return false;
});