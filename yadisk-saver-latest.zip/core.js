/* YaDisk Saver — общее ядро. Без обращений к DOM при загрузке.
   Страницы (popup/batch) задают LOGGER для вывода. */
let LOGGER = null;
function log(...a) {
  const s = a.join(" ");
  if (LOGGER) LOGGER(s);
  else console.log(s);
}
const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* Журнал с ограничением размера: DOM не должен расти бесконечно
   (в батче это сотни-тысячи строк).
   Строки копим в массиве и отдаём в DOM пачками (не чаще раза в 100 мс):
   раньше на каждую строку делалось el.textContent += ..., то есть текст
   пересобирался целиком (O(n^2) на длинных логах) и DOM перепарсивался. */
function attachLog(el, maxLines = 2000) {
  const lines = [];
  let timer = null;
  const flush = () => {
    timer = null;
    el.textContent = lines.join("\n");
    el.scrollTop = el.scrollHeight;
  };
  return (s) => {
    lines.push(String(s));
    if (lines.length > maxLines) lines.splice(0, lines.length - maxLines);
    if (timer === null) timer = setTimeout(flush, 100);
  };
}

/* Вкладки: показываем ровно одну панель, чтобы попап не прокручивался */
function initTabs(onSwitch) {
  const tabs = [...document.querySelectorAll("[data-tab]")];
  const panels = [...document.querySelectorAll("[data-panel]")];
  const show = (name) => {
    for (const t of tabs) t.setAttribute("aria-selected", String(t.dataset.tab === name));
    for (const p of panels) p.hidden = p.dataset.panel !== name;
    if (onSwitch) onSwitch(name);
  };
  for (const t of tabs) t.addEventListener("click", () => show(t.dataset.tab));
  const first = tabs.find((t) => t.getAttribute("aria-selected") === "true") || tabs[0];
  if (first) show(first.dataset.tab);
  return { show };
}

async function curTab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t;
}
function fetchOk(url, opts = {}) {
  return fetch(url, { credentials: "include", ...opts });
}

/* fetch с РЕАЛЬНЫМ таймаутом.
   Раньше таймаут был только параметром, который никто не использовал: зависший
   ответ блокировал скачивание навсегда, и «Остановить» не срабатывал.
   Таймер живёт до конца чтения тела (read), а не только до заголовков —
   иначе обрыв на середине большого сегмента снова ушёл бы в бесконечное ожидание.
   read — функция, читающая тело: r => r.arrayBuffer() / r.text() / r.blob().
   signal — внешний сигнал отмены; при его срабатывании бросаем "__CANCELLED__". */
async function fetchTimed(url, read, opts = {}, ms = 30000, signal) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  const onAbort = () => ctrl.abort();
  if (signal) signal.addEventListener("abort", onAbort, { once: true });
  const short = String(url).slice(0, 90);
  try {
    const r = await fetchOk(url, { ...opts, signal: ctrl.signal });
    if (!r.ok) {
      // тело ответа — критично для диагностики: по логу пользователь присылает скриншоты
      let body = "";
      try { body = (await r.text()).slice(0, 200); } catch (e) { /* тело недоступно */ }
      throw new Error("HTTP " + r.status + " (" + short + ")" + (body ? " " + body : ""));
    }
    return await read(r);
  } catch (e) {
    if (e && e.name === "AbortError") {
      if (signal && signal.aborted) throw new Error("__CANCELLED__");
      throw new Error("таймаут " + ms + " мс (" + short + ")");
    }
    throw e;
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener("abort", onAbort);
  }
}
const waitMs = sleep;
const fmtMB = (s) => ((s || 0) / 1048576).toFixed(1) + " МБ";

/* Версия в шапке — из манифеста, чтобы не расходилась с реальной */
(function showVersion() {
  try {
    const v = chrome.runtime.getManifest().version;
    document.querySelectorAll(".ver").forEach((el) => { el.textContent = v; });
  } catch (e) { /* вне расширения — просто пусто */ }
})();
/* Зарезервированные имена устройств Windows: CON, PRN, AUX, NUL, COM1-9, LPT1-9.
   Windows не даёт создать файл с таким именем даже с расширением («CON.pdf» — тоже
   нельзя), поэтому такие имена получают префикс «_». */
const RESERVED_WIN = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i;

/* Приводит имя к виду, пригодному для Windows:
   - заменяет запрещённые символы \ / : * ? " < > | на «_»;
   - убирает управляющие символы;
   - срезает хвостовые точки и пробелы (Windows их молча отбрасывает);
   - обходит зарезервированные имена устройств. */
function safeName(s) {
  let n = String(s == null || s === "" ? "file" : s)
    .replace(/[\\/:*?"<>|]/g, "_")
    .replace(/[\x00-\x1f\x7f]/g, "_")
    .replace(/[. ]+$/, "");
  const stem = n.split(".")[0];
  if (RESERVED_WIN.test(stem)) n = "_" + n;
  return n || "file";
}

/* Имя файла для сохранения: без расширения и без символов, запрещённых в Windows.
   Двоеточие особенно часто встречается в заголовках документов («План: Отчёт 2024»),
   и Chrome отказывался сохранять такой файл. Набор запрещённых символов берём
   из safeName — чтобы правила не разъезжались.
   Раньше это делалось вручную в popup.js, и там safeName забывали. */
function baseFileName(name, fallback = "document") {
  const raw = String(name == null ? "" : name).trim();
  if (!raw) return fallback;
  const s = safeName(raw).replace(/\.\w+$/, "").trim();
  return s || fallback;
}

/* ---------- Проверка обновлений ----------
   Расширение не может обновить себя само (Chrome не даёт), но может:
     - узнать, что вышла новая версия;
     - скачать zip новой версии;
     - сказать пользователю, что делать (распаковать поверх, нажать ⟳).
   Файл update.json лежит рядом с релизом на GitHub и содержит:
     { "version": "1.5.0", "url": "...zip", "notes": "...", "sha256": "..." }
   Список релизов GitHub отдаётся и без токена, поэтому проверка работает
   и для обычного пользователя (репозиторий публичный). */

const UPDATE_FEED = "https://raw.githubusercontent.com/bux212/yadisk-saver-dist/main/update.json";

/* Сравнение версий: "1.10.0" > "1.9.9" (числовое сравнение по частям). */
function compareVersions(a, b) {
  const pa = String(a || "0").split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "0").split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

/* Текущая версия расширения (из манифеста). */
function currentVersion() {
  try { return chrome.runtime.getManifest().version || "0"; } catch (e) { return "0"; }
}

/* Спросить у GitHub, есть ли новая версия.
   Возвращает {version, url, notes, sha256} — только если она НОВЕЕ текущей,
   иначе null. */
async function fetchUpdateInfo(timeout = 15000) {
  try {
    // credentials:"omit" — лента публичная, cookies не нужны.
    // С credentials:"include" браузер рубит ответ: raw.githubusercontent.com
    // отдаёт Access-Control-Allow-Origin: * , а вместе с cookies это
    // запрещённая комбинация — запрос падал бы с CORS-ошибкой.
    const j = await fetchTimed(UPDATE_FEED, (r) => r.json(), { credentials: "omit" }, timeout);
    if (!j || !j.version || !j.url) return null;
    if (compareVersions(j.version, currentVersion()) <= 0) return null;
    return { version: j.version, url: j.url, notes: j.notes || "", sha256: j.sha256 || "" };
  } catch (e) {
    return null;   // нет сети или битый ответ — не мешаем работе расширения
  }
}

/* Имя видеофайла из вкладок Диска.
   Источник — URL страницы файла: .../d/<id>/<путь>/ScreenRecorderProject18.mp4
   -> "ScreenRecorderProject18". Активная вкладка приоритетнее, но если
   активна вкладка расширения (grab.html), смотрим остальные. */
async function videoNameFromTabs(tabs) {
  const list = tabs || [];
  const fileRe = /\.([A-Za-z0-9]{2,5})$/;
  const isFile = (u) => {
    try { return fileRe.test(decodeURIComponent(new URL(u).pathname)); }
    catch (e) { return false; }
  };
  const active = list.find((t) => t.active);
  const cands = [active, ...list].filter((t) =>
    t && /disk\.yandex\.ru/.test(t.url || "") && isFile(t.url));
  if (!cands.length) return "";
  const seg = decodeURIComponent(new URL(cands[0].url).pathname)
    .split("/").filter(Boolean).pop();
  return seg.replace(fileRe, "") || "";
}

function concat(arr) {
  const n = arr.reduce((s, b) => s + b.length, 0);
  const r = new Uint8Array(n);
  let o = 0;
  for (const b of arr) { r.set(b, o); o += b.length; }
  return r;
}

/* Размер страницы PDF.
   Раньше MediaBox ставился в пикселях картинки: страница получалась
   1588 x 2246 пунктов = 22.1 x 31.2 дюйма. На экране это незаметно,
   но при печати лист уезжал за край, а в свойствах PDF показывалась
   несуществующая бумага. Теперь страница — A4 (595.276 x 841.89 пункта),
   картинка вписывается в неё с сохранением пропорций и центрируется. */
const PDF_A4_W = 595.276, PDF_A4_H = 841.89;

/* Число для PDF: округляем и убираем хвост нулей */
const pdfNum = (n) => String(Math.round(n * 1000) / 1000);

/* Прямоугольник страницы под картинку: ориентация по пропорциям картинки,
   вписывание с сохранением пропорций, центрирование. */
function pdfPageBox(imgW, imgH) {
  const landscape = imgW > imgH;
  const pw = landscape ? PDF_A4_H : PDF_A4_W;
  const ph = landscape ? PDF_A4_W : PDF_A4_H;
  const scale = Math.min(pw / imgW, ph / imgH);
  const dw = imgW * scale, dh = imgH * scale;
  return { pw, ph, dw, dh, dx: (pw - dw) / 2, dy: (ph - dh) / 2 };
}

/* Страница-картинка для PDF.
   data — байты изображения, filter — /FlateDecode или /DCTDecode,
   decode — дополнительные параметры (для lossless: предикатор PNG). */
function pdfImage(data, w, h, filter, decode) {
  return { data, w, h, filter, decode: decode || "" };
}

/* Разбор PNG: заголовок и склеенный IDAT-поток.
   PNG от docviewer — RGB, 8 бит, без чересстрочности. Его IDAT уже является
   zlib-потоком с PNG-предикторами, а PDF умеет ровно то же
   (/FlateDecode + /Predictor 15). Поэтому картинку можно положить в PDF
   как есть — без пережатия и без потери качества. */
function parsePng(buf) {
  const u8 = new Uint8Array(buf);
  const dv = new DataView(buf);
  const SIG = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
  if (u8.length < 8) return null;
  for (let i = 0; i < 8; i++) if (u8[i] !== SIG[i]) return null;
  let pos = 8, ihdr = null, idat = [];
  while (pos + 8 <= u8.length) {
    const len = dv.getUint32(pos);
    const type = String.fromCharCode(u8[pos + 4], u8[pos + 5], u8[pos + 6], u8[pos + 7]);
    if (type === "IHDR") {
      ihdr = {
        w: dv.getUint32(pos + 8), h: dv.getUint32(pos + 12),
        depth: u8[pos + 16], color: u8[pos + 17], interlace: u8[pos + 20],
      };
    } else if (type === "IDAT") {
      idat.push(u8.subarray(pos + 8, pos + 8 + len));
    } else if (type === "IEND") {
      break;
    }
    pos += 12 + len;
  }
  if (!ihdr || !idat.length) return null;
  let total = 0;
  for (const c of idat) total += c.length;
  const z = new Uint8Array(total);
  let off = 0;
  for (const c of idat) { z.set(c, off); off += c.length; }
  return { w: ihdr.w, h: ihdr.h, depth: ihdr.depth, color: ihdr.color, interlace: ihdr.interlace, idat: z };
}

/* PNG -> картинка для PDF.
   Основной путь — lossless: PNG кладётся в PDF без пережатия (IDAT как
   /FlateDecode + /Predictor 15). Качество ровно как отдал сервер.
   Если PNG неподходящий (не RGB 8 бит, чересстрочность, шире maxW) —
   откатываемся на canvas в JPEG. */
async function pngToPdfImage(blob, maxW = 1588) {
  try {
    const png = await parsePng(await blob.arrayBuffer());
    if (png && png.color === 2 && png.depth === 8 && !png.interlace && png.w <= maxW) {
      return pdfImage(png.idat, png.w, png.h, "FlateDecode",
        `/DecodeParms << /Predictor 15 /Colors 3 /BitsPerComponent 8 /Columns ${png.w} >>`);
    }
  } catch (e) {
    log("  PNG разобрать не удалось (" + e.message + ") -> JPEG");
  }
  const j = await pngBlobToJpeg(blob, maxW);
  return pdfImage(j.jpeg, j.w, j.h, "DCTDecode", "");
}

/* Минимальная сборка PDF из JPEG (без библиотек, двухпроходная) */
function buildPdf2(pages) {
  const te = new TextEncoder();
  const total = 2 + pages.length * 3;
  const bodies = {};
  bodies[1] = te.encode(`<< /Type /Catalog /Pages 2 0 R >>`);
  const kids = pages.map((_, i) => `${3 + i * 3} 0 R`).join(" ");
  bodies[2] = te.encode(`<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
  pages.forEach((p, i) => {
    const pg = 3 + i * 3, ct = pg + 1, im = pg + 2;
    const box = pdfPageBox(p.w, p.h);
    bodies[pg] = te.encode(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pdfNum(box.pw)} ${pdfNum(box.ph)}] /Resources << /XObject << /Im${i} ${im} 0 R >> >> /Contents ${ct} 0 R >>`);
    const cs = te.encode(`q\n${pdfNum(box.dw)} 0 0 ${pdfNum(box.dh)} ${pdfNum(box.dx)} ${pdfNum(box.dy)} cm\n/Im${i} Do\nQ\n`);
    bodies[ct] = concat([te.encode(`<< /Length ${cs.length} >>\nstream\n`), cs, te.encode("endstream")]);
    const dec = p.decode ? " " + p.decode : "";
    bodies[im] = concat([
      te.encode(`<< /Type /XObject /Subtype /Image /Width ${p.w} /Height ${p.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /${p.filter}${dec} /Length ${p.data.length} >>\nstream\n`),
      p.data, te.encode("endstream"),
    ]);
  });
  const out = [];
  let off = 0;
  const offsets = {};
  const push = (b) => { out.push(b); off += b.length; };
  push(te.encode("%PDF-1.4\n"));
  for (let i = 1; i <= total; i++) {
    offsets[i] = off;
    push(te.encode(`${i} 0 obj\n`));
    push(bodies[i]);
    push(te.encode("\nendobj\n"));
  }
  const xrefPos = off;
  push(te.encode(`xref\n0 ${total + 1}\n0000000000 65535 f \n`));
  for (let i = 1; i <= total; i++) push(te.encode(String(offsets[i]).padStart(10, "0") + " 00000 n \n"));
  push(te.encode(`trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`));
  return new Blob(out, { type: "application/pdf" });
}

async function pngBlobToJpeg(blob, maxW = 1588) {
  const bmp = await createImageBitmap(blob);
  const scale = Math.min(1, maxW / bmp.width);
  const w = Math.round(bmp.width * scale), h = Math.round(bmp.height * scale);
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const cx = cv.getContext("2d");
  cx.fillStyle = "#fff"; cx.fillRect(0, 0, w, h);
  cx.drawImage(bmp, 0, 0, w, h);
  bmp.close();
  const dataUrl = cv.toDataURL("image/jpeg", 0.9);
  const bin = atob(dataUrl.split(",")[1]);
  const jpeg = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) jpeg[i] = bin.charCodeAt(i);
  return { jpeg, w, h };
}

/* ya-disk-public-ссылка из URL страницы документа.
   Старый вид: docs.yandex.ru/docs/view?url=ya-disk-public://<hash>:<путь>
   Новый вид : docs.yandex.ru/view/public/<hash>:<путь> (внутри — без схемы) */
function yaUrlFromPageUrl(pageUrl) {
  let u;
  try { u = new URL(pageUrl); } catch (e) { return null; }
  const direct = u.searchParams.get("url");
  if (direct && direct.startsWith("ya-disk-public://")) return direct;
  const m = u.pathname.match(/\/view\/public\/(.+)$/);
  if (m) {
    try { return "ya-disk-public://" + decodeURIComponent(m[1]); }
    catch (e) { return null; }
  }
  return null;
}

/* Имя файла из ya-disk-public-ссылки: после двоеточия путь внутри публикации. */
function nameFromYaUrl(yaUrl) {
  const m = /^ya-disk-public:\/\/[^:]*:(.+)$/.exec(String(yaUrl || ""));
  if (!m) return "";
  const parts = m[1].split("/").filter(Boolean);
  return parts.length ? parts[parts.length - 1] : "";
}

/* MIME-типы офисных форматов. Нужны, потому что Chrome берёт расширение
   итогового файла из MIME-типа blob-а: у blob-а без типа он подставляет
   ".txt" и файл «Статья от нутрициолога.docx» сохраняется как
   «Статья от нутрициолога.txt» — нечитаемый в Word. */
const MIME_BY_EXT = {
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  doc: "application/msword",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  xls: "application/vnd.ms-excel",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ppt: "application/vnd.ms-powerpoint",
  odt: "application/vnd.oasis.opendocument.text",
  ods: "application/vnd.oasis.opendocument.spreadsheet",
  odp: "application/vnd.oasis.opendocument.presentation",
  rtf: "application/rtf",
  txt: "text/plain",
  pdf: "application/pdf",
};

/* MIME по имени файла; "" — если формат неизвестен. */
function mimeForName(name) {
  const m = /\.([A-Za-z0-9]{1,6})$/.exec(String(name || ""));
  return m ? (MIME_BY_EXT[m[1].toLowerCase()] || "") : "";
}

/* Самая маленькая превью-картинка файла — для списка в UI.
   cloud-api отдаёт item.sizes[] (ссылки разных размеров: XXS…XXXL) и item.preview.
   Размер в ссылке задан параметром ?size=, по нему и выбираем самый мелкий. */
const THUMB_ORDER = { XXS: 1, XS: 2, S: 3, M: 4, L: 5, XL: 6, XXL: 7, XXXL: 8 };

function pickThumb(item) {
  const sizes = (item && item.sizes) || [];
  let best = "", bestRank = 99;
  for (const s of sizes) {
    const u = s && s.url ? s.url : "";
    if (!u) continue;
    const m = /[?&]size=([^&]+)/.exec(u);
    const rank = m ? (THUMB_ORDER[m[1].toUpperCase()] || 99) : 99;
    if (rank < bestRank) { bestRank = rank; best = u; }
  }
  if (!best && item && item.preview) best = item.preview;
  return best;
}

/* Экранирование для вставки в HTML (миниатюры содержат & и ") */
const escHtml = (s) => String(s == null ? "" : s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

/* Оригинал документа — через WOPI.
   Яндекс для РЕДАКТИРУЕМЫХ форматов (docx/xlsx/pptx) отдаёт сам файл:
   страница https://docs.yandex.ru/view/public/<hash:path> содержит в HTML
   officeActionData с access_token и resource_url, а
   GET resource_url/contents?access_token=... отдаёт исходные байты файла.
   Проверено 12.11.2026: md5, sha256 и размер совпали с cloud-api до байта.

   Для PDF этот путь не работает (PDF уходят в старый просмотрщик, там
   access_token нет) — возвращаем null, и вызывающий рисует PDF из картинок.

   yaUrl — вида "ya-disk-public://<hash>:<путь>". */
async function fetchOriginalFile(yaUrl, timeout = 30000) {
  const m = /^ya-disk-public:\/\/(.+)$/.exec(String(yaUrl || ""));
  if (!m) return null;
  const viewUrl = "https://docs.yandex.ru/view/public/" + encodeURIComponent(m[1]);
  let html;
  try {
    html = await fetchTimed(viewUrl, (r) => r.text(), {}, timeout);
  } catch (e) {
    log("  оригинал: страница документа не открылась (" + e.message + ")");
    return null;
  }
  const tok = html.match(/"access_token"\s*:\s*"([^"]+)"/);
  const res = html.match(/"resource_url"\s*:\s*"([^"]+)"/);
  if (!tok || !res) return null;   // формат без WOPI (PDF) — рисуем сами
  const url = res[1] + "/contents?access_token=" + encodeURIComponent(tok[1]);
  try {
    let ctype = "";
    const buf = await fetchTimed(url, async (r) => {
      ctype = r.headers.get("content-type") || "";
      return await r.arrayBuffer();
    }, {}, timeout);
    if (!buf.byteLength) return null;
    // тип берём с сервера, а если он пуст — по расширению имени файла
    const type = (ctype || mimeForName(nameFromYaUrl(yaUrl)) || "application/octet-stream").split(";")[0].trim();
    return { blob: new Blob([buf], { type }), bytes: buf.byteLength, type };
  } catch (e) {
    log("  оригинал: не скачался (" + e.message + ")");
    return null;
  }
}

/* Документ из просмотрщика -> PDF Blob */
async function docToPdfBlob(yaUrl, name, onProg) {
  const q = new URLSearchParams({ url: yaUrl, name, embed: "docs", nosw: "1" });
  const html = await fetchTimed("https://docviewer.yandex.ru/?" + q, (r) => r.text(), {}, 30000);
  const mU = html.match(/"pathname"\s*:\s*"\/view\/(\d+)\/"/);
  const mT = html.match(/"token"\s*:\s*"([^"]+)"/);
  const mD = html.match(/"dsid"\s*:\s*"([^"]+)"/);
  if (!(mU && mT && mD)) throw new Error("Не извлёк token/uid/dsid");
  return docToPdfBlobFromToken(mU[1], mT[1], mD[1], onProg);
}

async function docToPdfBlobFromToken(uid, token, dsid, onProg) {
  // статус опрашиваем, пока документ готовится (большие PDF рендерятся не сразу)
  let fileId = null, pages = [];
  for (let t = 0; t < 15; t++) {
    const stQ = new URLSearchParams({ "*": token, dsid });
    const st = await fetchTimed("https://docviewer.yandex.ru/api/status?" + stQ, (r) => r.json(), {
      method: "POST", headers: { "Content-Type": "application/json" }, body: "{}"
    }, 30000);
    if (st.error) throw new Error("status error: " + JSON.stringify(st).slice(0, 200));
    token = st.token || token;
    fileId = (st.data && st.data.fileId) || fileId;
    pages = (st.data && st.data.pages) || [];
    if (st.data && st.data.state === "READY" && pages.length) break;
    if (t === 0) log("  подготовка документа на сервере…");
    if (t < 14) await waitMs(3000);
  }
  if (!pages.length) throw new Error("0 страниц (документ не подготовился за ~45 с)");
  log("  страниц: " + pages.length);
  const pdfPages = [];
  for (let i = 0; i < pages.length; i++) {
    const p = pages[i];
    const W = 1588, H = Math.round(W * (p["height-to-width"] || 1.415));
    const pgQ = new URLSearchParams({ "*": token });
    const resp = await fetchTimed("https://docviewer.yandex.ru/api/page?" + pgQ, (r) => r.json(), {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileId, page: i + 1, width: W, height: H })
    }, 30000);
    const frag = (resp.data && resp.data.html) || "";
    const mId = frag.match(/htmlimage\?id=([^&\\]+)/);
    const mDs = frag.match(/dsid=([a-z0-9]+)/);
    const imgQ = new URLSearchParams({
      id: mId ? mId[1] : fileId, width: W, height: H,
      name: `bg-${i}.png`, dsid: mDs ? mDs[1] : dsid
    });
    const blob = await fetchTimed(`https://docviewer.yandex.ru/view/${uid}/htmlimage?` + imgQ, (r) => r.blob(), {}, 60000);
    pdfPages.push(await pngToPdfImage(blob));
    if (onProg) onProg(i + 1, pages.length);
  }
  return { blob: buildPdf2(pdfPages), pages: pages.length };
}

/* ---------- Поток видео прямо из HTML страницы файла ----------
   В HTML страницы disk.yandex.ru/d/<id>/<путь> лежит блок "videoStreams":
   все качества с готовыми ссылками на плейлисты (240p…1080p + adaptive-master).
   Проверено 12.11.2026: страница отдаёт его даже с Origin расширения,
   cookies не нужны, а плейлисты и сегменты качаются напрямую.
   Значит плеер не нужен: ни вкладки, ни нажатия Play, ни перехвата m3u8.
   Сервер примерно в 20% случаев отдаёт HTML без videoStreams
   ("videoStreamsFetchError") — поэтому есть повтор запроса. */

/* Достаём объект "videoStreams" из HTML по балансу скобок.
   Строки не считаем: внутри URL встречаются и кавычки, и экранирование. */
function parseVideoStreams(html) {
  const i = String(html || "").indexOf('"videoStreams"');
  if (i < 0) return null;
  const start = String(html).indexOf("{", i);
  if (start < 0) return null;
  let depth = 0, inStr = false, esc = false;
  for (let k = start; k < html.length; k++) {
    const c = html[k];
    if (inStr) {
      if (esc) esc = false;
      else if (c === "\\") esc = true;
      else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === "{") depth++;
    else if (c === "}") {
      depth--;
      if (depth === 0) {
        try { return JSON.parse(html.slice(start, k + 1)); }
        catch (e) { return null; }
      }
    }
  }
  return null;
}

/* Страница файла -> варианты качества и master-плейлист.
   Возвращает {duration (мс), master, variants:[{label, width, height, url}]}
   или null, если в HTML потоков нет.

   Запрос идёт БЕЗ cookies (credentials:"omit"): анонимный SSR-вариант страницы
   детерминирован и всегда содержит videoStreams. С cookies Яндекс иногда отдаёт
   другую выдачу. Проверено 12.11.2026.

   Сервер примерно в 20% случаев отдаёт HTML без потоков
   ("videoStreamsFetchError") — поэтому запрос повторяется. */
async function fetchVideoStreams(pageUrl, tries = 4) {
  let last = "";
  for (let i = 0; i < tries; i++) {
    try {
      const html = await fetchTimed(pageUrl, (r) => r.text(), { credentials: "omit" }, 30000);
      const vs = parseVideoStreams(html);
      if (vs && vs.videos && vs.videos.length) {
        const variants = vs.videos
          .filter((v) => v && v.url && v.dimension && v.dimension !== "adaptive")
          .map((v) => ({
            label: v.dimension,
            width: (v.size || {}).width || 0,
            height: (v.size || {}).height || 0,
            url: v.url,
          }));
        const master = (vs.videos.find((v) => v.dimension === "adaptive") || {}).url || "";
        if (variants.length) return { duration: vs.duration || 0, master, variants };
        last = "в videoStreams нет вариантов";
      } else {
        last = "в HTML нет videoStreams";
      }
    } catch (e) {
      last = e.message;
    }
    // сервер иногда отдаёт страницу без потоков — повторяем
    if (i < tries - 1) await sleep(700 * (i + 1));
  }
  log("  поток из HTML не получен (" + last + ")");
  return null;
}

/* URL страницы файла на Диске по публикации и пути внутри неё.
   pageKey — "https://disk.yandex.ru/d/<id>", filePath — путь от корня. */
function diskFilePageUrl(pageKey, filePath) {
  const enc = String(filePath == null ? "" : filePath)
    .split("/").map(encodeURIComponent).join("/");
  return String(pageKey || "") + enc;
}

/* Страница файла на Диске? (а не папки/публикации)
   У файла в конце пути есть расширение. Только у таких страниц
   в HTML есть videoStreams — у папок его нет. */
function isDiskFilePage(url) {
  if (!/^https:\/\/disk\.yandex\.ru\/d\//.test(String(url || ""))) return false;
  try {
    const p = decodeURIComponent(new URL(url).pathname);
    return /\.[A-Za-z0-9]{1,6}$/.test(p);
  } catch (e) {
    return false;
  }
}

/* Страница ВИДЕО на Диске? Только такие стоит опрашивать на предмет
   потока: у PDF и документов videoStreams нет, а запрос к каждой
   вкладке стоит ~1.5 с — лишние запросы тормозят интерфейс. */
const VIDEO_EXT = /\.(mov|mp4|mkv|avi|webm|m4v|3gp|mts|m2ts|ts|flv|wmv|vob|ogv|mpe?g)$/i;
function isDiskVideoPage(url) {
  if (!isDiskFilePage(url)) return false;
  try {
    const p = decodeURIComponent(new URL(url).pathname);
    return VIDEO_EXT.test(p);
  } catch (e) {
    return false;
  }
}

/* Master-плейлист видео из URL страницы файла на Диске.
   Страница https://disk.yandex.ru/d/<id>/<путь> содержит в HTML блок
   "videoStreams" — все качества и ссылку на master-плейлист.
   Значит Play нажимать не нужно: поток берём из страницы.

   Возвращает master-URL или null (если это не страница видео
   или в HTML нет потоков). tries — сколько раз повторять запрос:
   сервер примерно в 20% случаев отдаёт страницу без потоков. */
async function videoMasterFromPage(pageUrl, tries = 3) {
  if (!isDiskVideoPage(pageUrl)) return null;
  const info = await fetchVideoStreams(pageUrl, tries);
  return info && info.master ? info.master : null;
}

/* HLS: список качеств мастер-плейлиста */
async function listQualities(masterUrl, signal) {
  const txt = await fetchTimed(masterUrl, (r) => r.text(), {}, 30000, signal);
  const found = [...txt.matchAll(/#EXT-X-STREAM-INF:[^\n]*BANDWIDTH=(\d+)[^\n]*RESOLUTION=(\S+)[^\n]*\n([^\n]+)/g)];
  if (!found.length) return [{ label: "поток", bw: 0, url: masterUrl }];
  return found.map((m) => ({ label: m[2], bw: +m[1], url: new URL(m[3].trim(), masterUrl).href }));
}

/* HLS вариант -> один Blob (.ts).
   quality: 'best' | '1080p' | '720p' | ... | '' (=как есть).
   Метки бывают двух видов: "608x1080" и "1080p" — сравниваем по высоте. */
function pickVariant(vars, quality) {
  if (!quality || quality === "best") return vars.reduce((a, b) => (b.bw > a.bw ? b : a));
  const h = +(String(quality).match(/(\d+)/) || [0, 0])[1];
  return vars.find((x) => {
    const m = x.label.match(/(\d+)x(\d+)/);
    return m && +m[2] === h;
  }) || vars.find((x) => x.label.startsWith(quality)) || null;
}

/* fetch с повторами: сегмент HLS отваливается от одного 502 не должен ронять весь файл.
   timeout теперь настоящий (AbortController), signal — внешняя отмена.
   Таймаут повторяем: он может быть транзиентным (сеть моргнула).
   headers — доп. заголовки запроса (нужен для Range в #EXT-X-BYTERANGE). */
async function fetchRetry(url, tries = 3, timeout = 30000, signal, headers) {
  let last;
  for (let i = 0; i < tries; i++) {
    if (signal && signal.aborted) throw new Error("__CANCELLED__");
    try {
      return await fetchTimed(url, (r) => r.arrayBuffer(), headers || {}, timeout, signal);
    } catch (e) {
      if (String(e.message) === "__CANCELLED__") throw e;
      last = e;
      if (i < tries - 1) await sleep(700 * (i + 1));
    }
  }
  throw new Error("сегмент не скачался: " + (last && last.message));
}

/* Разбор плейлиста варианта по спецификации HLS.
   Возвращает {segs, mapUrl}:
     - segs[i].url      — адрес сегмента;
     - segs[i].headers  — Range-заголовок, если сегмент задан байт-диапазоном;
     - mapUrl           — init-сегмент fMP4 (#EXT-X-MAP), его надо поставить первым.
   Яндекс отдаёт MPEG-TS (init-сегмента нет), но если поток сменится на fMP4 —
   без этого получится битый файл. */
function parsePlaylist(txt, baseUrl) {
  const lines = txt.split("\n").map((s) => s.trim());
  const segs = [];
  let mapUrl = null;
  let pending = null;     // {len, off} из #EXT-X-BYTERANGE
  let lastUri = null, lastOff = 0;
  for (const line of lines) {
    if (!line) continue;
    if (line.charAt(0) === "#") {
      const mMap = /^#EXT-X-MAP:.*URI="([^"]+)"/.exec(line);
      if (mMap) { mapUrl = new URL(mMap[1], baseUrl).href; continue; }
      const mBr = /^#EXT-X-BYTERANGE:(\d+)(?:@(\d+))?/.exec(line);
      if (mBr) { pending = { len: +mBr[1], off: mBr[2] !== undefined ? +mBr[2] : null }; }
      continue;
    }
    const url = new URL(line, baseUrl).href;
    let headers = null;
    if (pending) {
      // без явного @offsetoffset продолжается с прошлого отрезка того же URI
      const start = pending.off !== null ? pending.off : (lastUri === url ? lastOff : 0);
      headers = { Range: "bytes=" + start + "-" + (start + pending.len - 1) };
      lastUri = url; lastOff = start + pending.len;
    }
    segs.push({ url, headers });
    pending = null;
  }
  return { segs, mapUrl };
}

async function hlsToBlob(masterUrl, quality, onProg, strictQuality, shouldStop) {
  // Отмена должна прерывать ТЕКУЩИЙ запрос, а не ждать конца сегмента:
  // раньше shouldStop проверялся только между сегментами, поэтому на зависшем
  // запросе кнопка «Остановить» не срабатывала.
  const ctrl = new AbortController();
  let poll = null;
  if (shouldStop) {
    poll = setInterval(() => { if (shouldStop()) ctrl.abort(); }, 300);
  }
  try {
    const vars = await listQualities(masterUrl, ctrl.signal);
    const v = pickVariant(vars, quality);
    if (!v) throw new Error("Нет качества " + quality + ". Есть: " + vars.map((x) => x.label).join(", "));
    if (strictQuality && v.label !== quality) {
      const m = v.label.match(/(\d+)x(\d+)/);
      if (!m || +m[2] !== +(String(quality).match(/(\d+)/) || [0, 0])[1]) {
        throw new Error(`Качества ${quality} нет — есть ${vars.map((x) => x.label).join(", ")}. Выбери другое.`);
      }
    }
    const txt = await fetchTimed(v.url, (r) => r.text(), {}, 30000, ctrl.signal);
    const { segs, mapUrl } = parsePlaylist(txt, v.url);
    if (!segs.length) throw new Error("Нет сегментов — ссылка протухла");
    // кладём части в Blob напрямую: ручная склейка в Uint8Array удваивала пик памяти
    const parts = [];
    let bytes = 0;
    // fMP4: init-сегмент должен идти первым, иначе файл не откроется
    if (mapUrl) {
      const buf = await fetchRetry(mapUrl, 3, 30000, ctrl.signal);
      const part = new Uint8Array(buf);
      parts.push(part);
      bytes += part.length;
    }
    for (let i = 0; i < segs.length; i++) {
      if (shouldStop && shouldStop()) throw new Error("__CANCELLED__");
      const buf = await fetchRetry(segs[i].url, 3, 30000, ctrl.signal, segs[i].headers);
      const part = new Uint8Array(buf);
      parts.push(part);
      bytes += part.length;
      if (onProg) onProg(i + 1, segs.length);
    }
    return { blob: new Blob(parts, { type: "video/mp2t" }), label: v.label, bytes, segments: segs.length };
  } finally {
    if (poll) clearInterval(poll);
  }
}

/* Скачивание Blob.
   blob-URL живёт до реального завершения загрузки: раньше стоял таймер
   на 60 с, и большой файл обрывался на середине.
   Отзыв делает СТРАНИЦА: в service worker нет URL.revokeObjectURL. */
const BLOB_MAX_AGE = 2 * 60 * 60 * 1000; // страховка, если событие потерялось

function revokeWhenDone(downloadId, url) {
  const done = { fired: false };
  const finish = () => {
    if (done.fired) return;
    done.fired = true;
    chrome.downloads.onChanged.removeListener(onChange);
    clearTimeout(timer);
    URL.revokeObjectURL(url);
  };
  const onChange = (delta) => {
    if (delta.id !== downloadId) return;
    const st = delta.state && delta.state.current;
    if (st === "complete" || st === "interrupted") finish();
  };
  chrome.downloads.onChanged.addListener(onChange);
  const timer = setTimeout(finish, BLOB_MAX_AGE);
}

async function downloadBlob(blob, filename, saveAs) {
  const u = URL.createObjectURL(blob);
  let id;
  try {
    id = await chrome.downloads.download({ url: u, filename, saveAs });
  } catch (e) {
    id = await new Promise((res) => chrome.downloads.download({ url: u, filename, saveAs }, res));
  }
  if (typeof id === "number") revokeWhenDone(id, u);
  else setTimeout(() => URL.revokeObjectURL(u), BLOB_MAX_AGE);
  return id;
}
