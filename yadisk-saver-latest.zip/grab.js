/* YaDisk Saver — одиночное скачивание видео в постоянной вкладке.
   Вкладка переживает переключение окон, в отличие от попапа. */
LOGGER = attachLog($("log"), 800);

let master = null;
let variants = [];
let running = false;
let cancelFlag = false;
/* Автостарт уже сработал (пришли из попапа) — второй раз не запускаем. */
let autoStarted = false;
/* Кэш потока по URL страницы: запрос стоит ~1.5 с и качает ~110 КБ,
   а опрос идёт каждые 5 с — без кэша это лишний трафик. */
const masterCache = new Map();   // url -> {master, at}
const MASTER_TTL = 60 * 1000;

async function findStream() {
  // 1. ссылка могла прийти из попапа
  const q = new URLSearchParams(location.search);
  const fromPopup = q.get("m");
  if (fromPopup && fromPopup.includes("m3u8")) return fromPopup;

  // 2. поток из HTML страницы видео на Диске: там лежит videoStreams
  //    со ссылкой на master-плейлист. Play нажимать не нужно.
  try {
    const tabs = await chrome.tabs.query({});
    // Активная вкладка — первой (запрос к странице ~1.5 с)
    const videoTabs = tabs
      .filter((t) => isDiskVideoPage(t.url))
      .sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0));
    for (const t of videoTabs) {
      // кэш: ту же страницу не качаем повторно
      const hit = masterCache.get(t.url);
      if (hit && Date.now() - hit.at < MASTER_TTL) {
        if (hit.master) return hit.master;
        continue;
      }
      const m = await videoMasterFromPage(t.url);
      masterCache.set(t.url, { master: m || "", at: Date.now() });
      if (m) return m;
    }
  } catch (e) { /* нет доступа к вкладкам — пробуем перехват */ }

  // 3. иначе берём последний пойманный поток из всех вкладок
  const res = await chrome.runtime.sendMessage({ type: "getPlaylists" }).catch(() => ({ items: [] }));
  const items = (res.items || [])
    .filter((e) => e.url.includes("m3u8"))
    .sort((a, b) => (b.ts || 0) - (a.ts || 0));
  if (!items.length) return null;
  return items.find((e) => e.url.includes("master-playlist")) || items[0].url;
}

/* Имя файла берём из URL вкладки с видео:
   https://disk.yandex.ru/d/<id>/<путь>/Видео смарт 1 часть.MOV -> "Видео смарт 1 часть"
   В пакетном режиме имя приходит из cloud-api, здесь — из адресной строки. */
async function guessName() {
  try {
    const tabs = await chrome.tabs.query({});
    const fileRe = /\.([A-Za-z0-9]{2,5})$/;
    const isFile = (u) => {
      try { return fileRe.test(decodeURIComponent(new URL(u).pathname)); }
      catch (e) { return false; }
    };
    const active = tabs.find((t) => t.active);
    const cands = [active, ...tabs].filter((t) => t && /disk\.yandex\.ru/.test(t.url || "") && isFile(t.url));
    if (!cands.length) return "video";
    const seg = decodeURIComponent(new URL(cands[0].url).pathname).split("/").filter(Boolean).pop();
    return seg.replace(fileRe, "") || "video";
  } catch (e) {
    return "video";
  }
}

async function init() {
  const info = $("gInfo");
  master = await findStream();
  if (!master) {
    info.innerHTML = '<span class="hint-bad">Поток не найден. Открой видео на Диске, нажми Play, потом вернись сюда и нажми «Обновить».</span>';
    $("gStart").disabled = true;
    log("Поток не пойман.");
    const b = document.createElement("button");
    b.className = "btn btn-sm";
    b.style.marginTop = "8px";
    b.textContent = "Обновить";
    b.onclick = init;
    info.appendChild(b);
    return;
  }
  try {
    variants = await listQualities(master);
  } catch (e) {
    info.innerHTML = `<span class="hint-bad">Ссылка протухла (${escHtml(e.message)}). Нажми Play на видео ещё раз и обнови здесь.</span>`;
    $("gStart").disabled = true;
    log("Плейлист не прочитался: " + e.message);
    return;
  }
  const sel = $("gQ");
  sel.innerHTML = "";
  variants.forEach((v, i) => {
    const kb = v.bw ? ` · ${Math.round(v.bw / 1000)} кбит/с` : "";
    sel.insertAdjacentHTML("beforeend", `<option value="${i}">${escHtml(v.label)}${kb}</option>`);
  });
  // качество, выбранное в попапе, переносим сюда
  const want = new URLSearchParams(location.search).get("q");
  if (want) {
    const idx = variants.findIndex((v) => v.label === want || v.label.startsWith(want));
    if (idx >= 0) {
      sel.value = String(idx);
      log(`Качество из попапа: ${variants[idx].label}`);
    } else {
      log(`Качества ${want} в этом видео нет, беру ${variants[0].label}`);
    }
  }
  // Имя файла. Попап передаёт его явно (?n=) — это надёжно.
  // Раньше имя угадывали только по вкладкам: если вкладка с роликом закрылась
  // или открыта не на /d/..., получалось «video».
  const qp = new URLSearchParams(location.search);
  const fromPopup = qp.get("n");
  if (!$("gName").value.trim() || $("gName").value === "video") {
    $("gName").value = (fromPopup && fromPopup.trim()) || (await guessName());
  }
  info.innerHTML = `<span class="hint-ok">Поток найден</span><code>${escHtml(master.slice(0, 100))}…</code>`;
  $("gStart").disabled = false;
  log("Качества: " + variants.map((v) => v.label).join(", "));
  log("Имя файла: " + $("gName").value);

  // Пришли из попапа (auto=1) — начинаем сразу, без второго нажатия.
  // Кнопка «Скачать» остаётся на случай, если захочется перекачать.
  // Флаг защищает от повторного автостарта: init() вызывается ещё и по таймеру.
  if (!autoStarted && new URLSearchParams(location.search).get("auto") === "1" && !running) {
    autoStarted = true;
    log("Запускаю автоматически (пришли из попапу).");
    startDownload();
  }
}

/* Само скачивание: вызывается и кнопкой, и автоматически. */
async function startDownload() {
  if (running) return;
  const v = variants[+$("gQ").value];
  if (!v) return;
  running = true; cancelFlag = false;
  $("gStart").disabled = true;
  $("gStop").disabled = false;
  const prog = $("gProg");
  prog.hidden = false; prog.value = 0;
  const t0 = Date.now();
  try {
    log(`Качаю ${v.label}…`);
    const res = await hlsToBlob(v.url, "", (i, n) => {
      prog.value = Math.round((i / n) * 100);
      if (i % 10 === 0 || i === n) log(`  сегмент ${i}/${n}`);
    }, false, () => cancelFlag);
    const secs = Math.round((Date.now() - t0) / 1000);
    const base = baseFileName($("gName").value.trim() || "video", "video");
    const name = `YaDiskSaver/${base}.${safeName(v.label)}.ts`;
    await downloadBlob(res.blob, name, false);
    log(`Готово: ${fmtMB(res.bytes)}, ${res.segments} сегм., ${secs} с.`);
    log(`Файл: ${name}`);
    log(`В MP4: ffmpeg -i "${base}.${v.label}.ts" -c copy "${base}.mp4"`);
  } catch (e) {
    if (String(e.message) === "__CANCELLED__") log("Остановлено.");
    else log("Ошибка: " + e.message);
  } finally {
    running = false;
    prog.hidden = true;
    $("gStart").disabled = false;
    $("gStop").disabled = true;
  }
}

$("gStart").onclick = startDownload;

$("gStop").onclick = () => {
  cancelFlag = true;
  $("gStop").disabled = true;
  log("Останавливаю после текущего сегмента…");
};

init();
// подхватываем поток, если он появился, пока страница была открыта.
// Не чаще раза в минуту: запрос страницы тяжёлый (~110 КБ).
let lastProbe = Date.now();
setInterval(() => {
  if (master) return;
  if (Date.now() - lastProbe < 60 * 1000) return;
  lastProbe = Date.now();
  init();
}, 5000);