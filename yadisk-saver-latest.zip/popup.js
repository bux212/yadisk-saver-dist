/* YaDisk Saver — попап: быстрые действия для одиночных файлов.
   Содержимое разделено по вкладкам, чтобы окно не прокручивалось. */
LOGGER = attachLog($("log"), 400);

// ВАЖНО: initTabs вызывается в конце файла, после того как все обработчики
// назначены. Раньше он стоял вверху и дёргал onSwitch до того, как
// api.refreshPlaylistBox существовал -> TypeError.
let videoTimer = null;

/* ---------- Проверка обновлений ----------
   Chrome не даёт расширению обновить себя самому, поэтому мы:
     - узнаём, что вышла новая версия;
     - даём скачать zip;
     - объясняем, как обновиться (распаковать и нажать ⟳).
   Проверка не должна мешать: при отсутствии сети просто ничего не показываем. */
/* ---------- Проверка обновлений ----------
   Chrome не даёт расширению обновить себя само (Chrome не даёт), поэтому мы:
     - узнаём, что вышла новая версия;
     - даём скачать zip;
     - объясняем, как обновиться (распаковать и нажать ⟳).
   Проверка не должна мешать: при отсутствии сети просто ничего не показываем.

   Сначала показываем сохранённое (фоновый воркер проверяет раз в час) — баннер
   появляется мгновенно; потом уточняем из сети. */
function showUpdateBanner(info) {
  const box = $("updBox");
  if (!box) return;
  if (!info) { box.hidden = true; return; }
  // Наполняем готовые элементы разметки: кнопка #btnUpd объявлена в popup.html
  // (все id, к которым обращается JS, должны быть в разметке — проверяет check_ids.py).
  const t = box.querySelector(".upd-t");
  const n = box.querySelector(".upd-n");
  const h = box.querySelector(".upd-h");
  const b = $("btnUpd");
  if (!t || !n || !h || !b) return;   // разметка изменилась — молча выходим
  t.innerHTML =
    `Доступна версия <b>${escHtml(info.version)}</b> (у тебя ${escHtml(currentVersion())})`;
  n.innerHTML = escHtml(info.notes);
  n.hidden = !info.notes;
  h.innerHTML =
    "Скачай zip, распакуй <b>поверх</b> старой папки расширения и нажми ⟳ " +
    "на странице chrome://extensions.";
  b.hidden = false;
  b.textContent = "Скачать " + info.version;
  b.onclick = async () => {
    b.disabled = true;
    try {
      await chrome.downloads.download({
        url: info.url,
        filename: `YaDiskSaver/yadisk-saver-${info.version}.zip`,
        conflictAction: "uniquify",
      });
      b.textContent = "Скачано ✓";
    } catch (e) {
      b.textContent = "Не вышло: " + e.message;
      b.disabled = false;
    }
  };
  box.hidden = false;
}

async function checkUpdate() {
  // 1) сохранённое (проверял фоновый воркер) — показываем сразу
  try {
    const r = await chrome.storage.local.get("update");
    if (r && r.update) showUpdateBanner(r.update);
  } catch (e) { /* хранилище недоступно — проверим из сети */ }
  // 2) уточняем из сети
  let info = null;
  try { info = await fetchUpdateInfo(); } catch (e) { info = null; }
  if (info) {
    try { await chrome.storage.local.set({ update: info }); } catch (e) { /* не критично */ }
    showUpdateBanner(info);
  } else if (!info) {
    // обновления нет: убираем и значок с иконки
    try {
      const r = await chrome.storage.local.get("update");
      if (!r || !r.update) showUpdateBanner(null);
    } catch (e) { /* игнорируем */ }
  }
}

$("btnPdf").onclick = async () => {
  const prog = $("pdfProg");
  const btn = $("btnPdf");
  btn.disabled = true; prog.hidden = false; prog.value = 0;
  try {
    const tab = await curTab();
    const url = new URL(tab.url);
    const qp = url.searchParams;
    // ссылка на файл внутри публикации: и старая форма (?url=), и новая (/view/public/)
    let yaUrl = qp.get("url") || yaUrlFromPageUrl(tab.url);
    let name = qp.get("name") || nameFromYaUrl(yaUrl) || "document.pdf";
    const mView = url.pathname.match(/\/view\/(\d+)\//);
    const onp = (i, n) => { prog.value = Math.round((i / n) * 100); };

    // HTML старого docviewer: в нём есть и токен/dsid, и полная ya-ссылка
    // (поле fileUrl; в пути бывают пробелы, поэтому берём поле целиком)
    let html = null;
    if (mView) {
      html = await fetchTimed(tab.url, (r) => r.text(), {}, 30000);
      if (!yaUrl) {
        const mYa = html.match(/"fileUrl"\s*:\s*"(ya-disk-public:\/\/[^"]+)"/);
        if (mYa) yaUrl = mYa[1];
      }
      const mN = html.match(/"title"\s*:\s*"([^"]+)"/);
      if (mN) name = mN[1];
    }

    // 1) ОРИГИНАЛ: docx/xlsx/pptx Яндекс отдаёт как есть (WOPI).
    //    Файл сохраняется с настоящим расширением, без перерисовки в PDF.
    if (yaUrl) {
      log("Документ: " + name);
      const orig = await fetchOriginalFile(yaUrl);
      if (orig) {
        await downloadBlob(orig.blob, safeName(name), true);
        log(`Готово: оригинал ${safeName(name)}, ${fmtMB(orig.bytes)}.`);
        return;
      }
      log("Оригинал недоступен (формат без WOPI) — собираю PDF из страниц.");
    }

    // 2) PDF из картинок просмотрщика (для PDF и прочего без оригинала)
    let blob, pages;
    if (mView) {
      const mD = html.match(/"dsid"\s*:\s*"([^"]+)"/);
      const mT = html.match(/"token"\s*:\s*"([^"]+)"/);
      const token = mT ? mT[1] : (qp.get("*") || "").replace(/ /g, "+");
      log("Документ: " + name);
      ({ blob, pages } = await docToPdfBlobFromToken(mView[1], token, mD ? mD[1] : "", onp));
    } else {
      if (!yaUrl) throw new Error("Это не страница просмотрщика — открой документ через docs.yandex.ru");
      log("Документ: " + name);
      ({ blob, pages } = await docToPdfBlob(yaUrl, name, onp));
    }
    // имя из заголовка документа может содержать ":" и "/" — Windows такие
    // символы в имени файла не допускает, Chrome отказывался сохранять.
    // Расширение ".pdf" — как у оригинала, без приставок вида ".viewer".
    await downloadBlob(blob, baseFileName(name) + ".pdf", true);
    log(`Готово: PDF, ${pages} стр. Качество как в просмотрщике, не оригинал.`);
  } catch (e) {
    log("Ошибка: " + e.message);
  } finally {
    btn.disabled = false;
    prog.hidden = true;
  }
};

/* ---------- Видео ---------- */
let variants = [];
let currentMaster = null;
/* Кэш потока по URL страницы: запрос к странице стоит ~1.5 с и качает
   ~110 КБ HTML, а попап обновляет список каждые 3 с. Без кэша это
   20 тяжёлых запросов в минуту впустую. */
const masterCache = new Map();   // url -> {master, at}
const MASTER_TTL = 60 * 1000;

async function onVideoTab() {
  await refreshPlaylistBox();
  clearTimeout(videoTimer);
  // пока попап открыт, подтягиваем поток: страница могла обновиться,
  // пока вкладка расширения была в фоне
  videoTimer = setInterval(() => {
    const t = document.querySelector('[data-tab="video"]');
    if (t && t.getAttribute("aria-selected") === "true" && !variants.length) {
      refreshPlaylistBox();
    }
  }, 3000);
}

async function refreshPlaylistBox() {
  const box = $("plist");
  const btn = $("btnVideo");
  let items = [];
  let master = null;
  let viaHtml = false;
  try {
    // смотрим и активную вкладку, и все вкладки Диска/плеера: видео может
    // играть не в той вкладке, которую сейчас видно
    const tabs = await chrome.tabs.query({});
    const ids = tabs
      .filter((t) => /disk\.yandex\.ru|docviewer|docs\.yandex\.ru/.test(t.url || ""))
      .map((t) => t.id);
    const [act, all] = await Promise.all([
      chrome.runtime.sendMessage({ type: "getPlaylists", tabId: ids[0] }).catch(() => ({ items: [] })),
      chrome.runtime.sendMessage({ type: "getPlaylists" }).catch(() => ({ items: [] })),
    ]);
    items = (all.items && all.items.length ? all.items : (act.items || []))
      .filter((e) => e.url.includes("m3u8"))
      .sort((a, b) => (b.ts || 0) - (a.ts || 0));

    // ГЛАВНЫЙ путь: в HTML страницы видео на Диске лежит блок "videoStreams"
    // со всеми качествами и ссылкой на master-плейлист. Значит нажимать Play
    // не нужно: страница уже содержит готовые ссылки на поток.
    // Проверено 12.11.2026 (HAR): GET страницы файла -> videoStreams.
    // Активная вкладка — первой: запрос к странице ~1.5 с, а вкладок
    // Диска может быть несколько.
    const diskTabs = tabs
      .filter((t) => isDiskVideoPage(t.url))
      .sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0));
    for (const t of diskTabs) {
      // кэш: ту же страницу не качаем повторно
      const hit = masterCache.get(t.url);
      if (hit && Date.now() - hit.at < MASTER_TTL) {
        if (hit.master) { master = hit.master; viaHtml = true; break; }
        continue;
      }
      try {
        const m = await videoMasterFromPage(t.url);
        masterCache.set(t.url, { master: m || "", at: Date.now() });
        if (m) { master = m; viaHtml = true; break; }
      } catch (e) { /* это не видео — пробуем следующую вкладку */ }
    }
  } catch (e) {
    box.innerHTML = '<span class="hint-bad">Нет доступа к вкладкам</span>';
    btn.disabled = true;
    return;
  }

  if (!master) {
    // запасной путь: пойманный m3u8 (пользователь нажал Play)
    const caught = items.find((e) => e.url.includes("master-playlist")) || items[0];
    master = caught ? caught.url : null;
  }
  if (!master) {
    box.innerHTML = '<span class="hint">Поток не найден. Открой видео на Диске и обнови — нажимать Play не нужно, поток берётся из самой страницы.</span>';
    btn.disabled = true;
    return;
  }
  // URL и сообщение экранируем: они попадают в innerHTML
  box.innerHTML = viaHtml
    ? `<span class="hint-ok">Поток взят из страницы (Play нажимать не нужно)</span><code>${escHtml(master.slice(0, 96))}…</code>`
    : `<span class="hint-ok">Поток пойман (${items.length})</span><code>${escHtml(master.slice(0, 96))}…</code>`;
  try {
    await renderQualities(master);
  } catch (e) {
    btn.disabled = true;
    $("quals").innerHTML = `<span class="hint-bad">Ссылка протухла: ${escHtml(e.message)}. Обнови страницу с видео (F5).</span>`;
  }
}

async function renderQualities(masterUrl) {
  variants = await listQualities(masterUrl);
  currentMaster = masterUrl;
  const box = $("quals");
  box.innerHTML = "";
  for (const [i, v] of variants.entries()) {
    const kb = v.bw ? ` · ${Math.round(v.bw / 1000)} кбит/с` : "";
    box.insertAdjacentHTML("beforeend",
      `<label class="opt"><input type=radio name=q value=${i} ${i === 0 ? "checked" : ""}><span>${v.label}${kb}</span></label>`);
  }
  $("btnVideo").disabled = false;
}

$("btnReload").onclick = async () => {
  $("btnReload").disabled = true;
  try {
    // кэш сбрасываем: пользователь мог обновить (F5) страницу с видео
    masterCache.clear();
    await refreshPlaylistBox();
  } finally {
    $("btnReload").disabled = false;
  }
};

$("btnLoadQ").onclick = async () => {
  const u = $("manualUrl").value.trim();
  if (!u) return;
  try {
    await renderQualities(u);
    log("Качества загружены из ссылки.");
  } catch (e) {
    log("Плейлист не прочитался: " + e.message + ". Возьми свежую ссылку из DevTools.");
  }
};

/* Скачивание уходит в постоянную вкладку: попап закрывается при
   переключении окна и убивает загрузку. Здесь только запуск.
   Передаём master-плейлист, а не выбранный вариант: только в master
   перечислены качества, иначе на странице будет единственный «поток».

   Вкладка открывается В ФОНЕ (active:false): пользователь остаётся
   на видео, а загрузка идёт сама. auto=1 — скачивание стартует сразу,
   без второго нажатия «Скачать». */
$("btnVideo").onclick = async () => {
  if (!currentMaster) return;
  const sel = document.querySelector("input[name=q]:checked");
  const v = variants[sel ? +sel.value : 0];
  const p = new URLSearchParams({ m: currentMaster });
  if (v) p.set("q", v.label);
  p.set("auto", "1");
  // Имя передаём ЯВНО: иначе grab.html угадывает его по вкладкам и часто
  // получается «video» (вкладка с роликом закрыта, открыта не на /d/... и т.п.).
  try {
    const tabs = await chrome.tabs.query({});
    const name = await videoNameFromTabs(tabs);
    if (name) p.set("n", name);
  } catch (e) { /* неcritical — grab.js попробует сам */ }
  chrome.tabs.create({
    url: chrome.runtime.getURL("grab.html") + "?" + p.toString(),
    active: false,
  });
  window.close();
};

$("btnBatchOpen").onclick = () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("batch.html") });
};

// инициализация вкладок — в самом конце, когда все функции уже объявлены
initTabs((name) => { if (name === "video") onVideoTab(); });

// проверка обновления — в фоне, чтобы не задерживать открытие попапа
checkUpdate();
