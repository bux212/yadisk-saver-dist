/* YaDisk Saver — пакетное скачивание папки (работает в отдельной вкладке batch.html,
   поэтому переживает переключение вкладок; попап для этого не годится — он закрывается). */
LOGGER = attachLog($("log"), 2000);

let batchFiles = [];
let batchCtx = null;
let batchRunning = false;
let batchCancel = false;
/* Расширения, для которых оригинала нет (PDF и подобные). Запоминаем,
   чтобы не делать лишний запрос к серверу на каждом таком файле. */
const origUnsupported = new Set();

function kindOf(name, mime) {
  const n = (name || "").toLowerCase();
  if (/\.(pdf|docx?|xlsx?|pptx?|odt|ods|odp|txt|rtf)$/.test(n)) return "doc";
  if (/\.(mov|mp4|avi|mkv|webm|m4v|3gp)$/.test(n) || (mime || "").startsWith("video")) return "video";
  if (/\.(m4a|mp3|wav|ogg|flac|aac)$/.test(n) || (mime || "").startsWith("audio")) return "audio";
  return "other";
}

/* Облачный API Яндекса — ЕДИНСТВЕННЫЙ источник списка файлов, работающий
   из расширения. Проверено экспериментально:
     - cloud-api .../resources -> 200, Access-Control-Allow-Origin эхоит origin
       расширения; отдаёт size, media_type, mime_type, preview, sizes[], md5, sha256;
     - site-API (disk.yandex.ru/public/api/fetch-list) -> 403 при
       Origin: chrome-extension://... (сервер режет origin расширения), поэтому
       запасная ветка через sk/hash со страницы была мёртвой и удалена.
   Ошибки повторяем: 5xx и обрывы сети — временные; 4xx (кроме 429) — нет. */
async function cloudList(publicKey, path, offset = 0) {
  const q = new URLSearchParams({ public_key: publicKey, path, limit: "200", offset: String(offset) });
  const url = "https://cloud-api.yandex.net/v1/disk/public/resources?" + q;
  let last = "";
  for (let i = 0; i < 3; i++) {
    try {
      return await fetchTimed(url, (r) => r.json(), {}, 30000);
    } catch (e) {
      last = e.message;
      // 4xx (кроме 429) — ответ сервера окончательный, повтор бессмыслен
      if (/HTTP 4\d\d/.test(last) && !/HTTP 429/.test(last)) break;
      if (i < 2) await waitMs(800 * (i + 1));
    }
  }
  throw new Error("cloud-api: " + last);
}

/* Рекурсивный обход папки. Глубина ограничена: на диске встречаются
   вложенности больше 10, а бесконечная рекурсия съест стек. */
async function cloudWalk(publicKey, path, out, depth = 0) {
  if (depth > 12) { log("  (слишком глубокая вложенность — обход остановлен)"); return; }
  let offset = 0;
  while (true) {
    const d = await cloudList(publicKey, path, offset);
    const emb = d._embedded;
    if (!emb || !(emb.items || []).length) {
      if (d.type === "file") out.push(d);
      return;
    }
    for (const it of emb.items) {
      if (it.type === "file") out.push(it);
      else if (it.type === "dir") await cloudWalk(publicKey, it.path, out, depth + 1);
    }
    offset += emb.items.length;
    if (offset >= (emb.total || 0)) return;
  }
}

/* Запасной список через API самого сайта — УДАЛЁН.
   site-API (disk.yandex.ru, public/api/fetch-list) режет Origin расширения:
     Origin: chrome-extension://... -> 403 {"error":true}
     Origin: https://disk.yandex.ru -> 400 {"wrongSk":true,"newSk":"..."}
   то есть из расширения он не работает НИКАК, а sk ещё и протухает за минуты.
   Проверено экспериментально 12.11.2026.
   Рабочий источник — cloud-api (см. cloudList выше). */

function diskKeyFromTabUrl(url) {
  const m = url.match(/^(https:\/\/disk\.yandex\.ru\/d\/[^/?#]+)(\/[^?#]*)?/);
  if (!m) return null;
  let basePath = m[2] ? decodeURIComponent(m[2]) : "/";
  basePath = basePath.replace(/\/+$/, "") || "/";
  return { pageKey: m[1], basePath };
}

/* Ищем вкладку с ПАПКОЙ, а не с видеофайлом: videoViaTab сам открывает
   disk.yandex.ru/d/ID/путь/файл.MOV, и такой URL тоже матчится под d/*.
   Из видеовкладки взялся бы не тот публичный ключ, и список вышел бы не по тому. */
async function findDiskTab() {
  const tabs = await chrome.tabs.query({ url: "*://disk.yandex.ru/d/*" });
  const isFile = (u) => {
    try { return /\.[A-Za-z0-9]{2,5}$/.test(decodeURIComponent(new URL(u).pathname)); }
    catch (e) { return false; }
  };
  return tabs.find((t) => !isFile(t.url)) || null;
}

function refreshButtons() {
  $("btnBatchGo").disabled = batchRunning || !batchFiles.some((f) => f.checked);
  $("btnBatchStop").disabled = !batchRunning;
  $("btnBatchClear").disabled = batchRunning || !batchFiles.some((f) => f.checked);
  $("btnBatchList").disabled = batchRunning;
}

$("btnBatchClear").onclick = () => {
  batchFiles.forEach((f) => (f.checked = false));
  $("batchList").querySelectorAll("input").forEach((cb) => (cb.checked = false));
  refreshButtons();
};

$("btnBatchStop").onclick = () => {
  batchCancel = true;
  log("Остановка после текущего файла…");
  $("btnBatchStop").disabled = true;
};

$("btnBatchList").onclick = async () => {
  try {
    let key = $("batchKey").value.trim();
    let basePath = "/";
    const manual = key.match(/^(https:\/\/disk\.yandex\.ru\/d\/[^/?#]+)(\/[^?#]*)?/);
    if (manual) {
      key = manual[1];
      basePath = (manual[2] ? decodeURIComponent(manual[2]) : "/").replace(/\/+$/, "") || "/";
    } else {
      if (key && !key.startsWith("https://disk.yandex.ru/d/")) { log("Ссылка должна быть вида https://disk.yandex.ru/d/XXXX"); return; }
      const dt = await findDiskTab();
      if (!dt) { log("Открой папку на disk.yandex.ru/d/... или вставь ссылку в поле."); return; }
      if (!key) {
        const parsed = diskKeyFromTabUrl(dt.url);
        if (!parsed) { log("Не понял URL вкладки."); return; }
        key = parsed.pageKey;
        basePath = parsed.basePath;
      }
    }
    const pubId = key.split("/d/")[1];
    log("Читаю список: " + key + " " + basePath);
    let rootHash = "", rootName = "";
    try {
      const rd = await cloudList(key, "/");
      rootHash = rd.public_key || "";
      rootName = rd.name || "";
    } catch (e) {
      log("корень cloud-api: " + e.message);
    }
    batchCtx = { pageKey: key, pubId, basePath, rootHash, rootName };
    const raw = [];
    try {
      await cloudWalk(key, basePath, raw);
    } catch (e) {
      // Запасного обхода через site-API больше нет: он режет Origin расширения (403).
      // Сообщаем ровно то, что произошло, — по логу видно, что делать.
      log("Список не прочитан: " + e.message);
      log("Если ошибка 403/404 — публикация закрыта или изменилась. Если 5xx — попробуй ещё раз.");
      throw new Error(e.message);
    }
    batchFiles = raw.map((f) => {
      const kind = kindOf(f.name, f.mime_type);
      return {
        path: f.path, name: f.name, size: f.size || 0, mime: f.mime_type || "",
        kind, checked: kind === "doc" || kind === "video",
        thumb: pickThumb(f),   // миниатюра из cloud-api (sizes[]), для списка
      };
    });
    const total = batchFiles.reduce((s, f) => s + f.size, 0);
    const byKind = batchFiles.reduce((m, f) => (m[f.kind] = (m[f.kind] || 0) + 1, m), {});
    log(`Найдено файлов: ${batchFiles.length}, ~${fmtMB(total)} (📄 ${byKind.doc || 0} · 🎬 ${byKind.video || 0} · 🔇 ${byKind.audio || 0})`);

    const badge = { doc: "📄", video: "🎬", audio: "🔇", other: "❓" };
    const box = $("batchList");
    box.innerHTML = "";
    for (const [i, f] of batchFiles.entries()) {
      const disabled = f.kind === "audio" || f.kind === "other";
      const note = f.kind === "audio" ? " · недоступен при запрете" : "";
      const thumb = f.thumb
        ? `<img class="thumb" src="${escHtml(f.thumb)}" loading="lazy" alt="">`
        : `<span class="thumb thumb-none"></span>`;
      box.insertAdjacentHTML("beforeend",
        `<label class="frow" title="${escHtml(f.path)}">
           <input type=checkbox data-i=${i} ${f.checked ? "checked" : ""} ${disabled ? "disabled" : ""}>
           ${thumb}
           <span>${badge[f.kind]}</span>
           <span class="name">${escHtml(f.name)}</span>
           <span class="size">${fmtMB(f.size)}${note}</span>
         </label>`);
    }
    box.querySelectorAll("input").forEach((cb) => {
      cb.onchange = () => { batchFiles[+cb.dataset.i].checked = cb.checked; refreshButtons(); };
    });
    refreshButtons();
  } catch (e) { log("ОШИБКА списка: " + e.message); }
};

/* Автозапуск видео в фоновой вкладке.
   ВНИМАНИЕ, из опыта 12.11.2026 (дважды ломало автозапуск):
   1) play() НЕЛЬЗЯ ЖДАТЬ. Сайт подменяет элемент <video> (превью -> полный
      ролик) и отменяет наш play() — прилетает AbortError, хотя воспроизведение
      идёт штатно. Ожидание ещё и блокировало поток на 5 с.
   2) НЕЛЬЗЯ выбирать «самое большое» видео: первый <video> в DOM и есть рабочий,
      а по размеру попадало в превью или рекламу — ролик не запускался.
   Поэтому: запускаем play() и НЕ ждём, а успех определяем по пойманному потоку
   (m3u8) — это единственный честный признак. */
async function tryAutoPlay(tabId) {
  try {
    const [r] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const v = document.querySelector("video");
        if (v) {
          v.muted = true;
          const p = v.play();
          if (p) p.catch(() => {});   // AbortError бывает и при нормальной игре
          return "видео: play()";
        }
        // Кликаем только по КОРОТКОЙ кнопке с подписью про воспроизведение:
        // в списке файлов есть «Смотреть», и такой клик уводит на другую страницу.
        const any = [...document.querySelectorAll("button")].find((b) => {
          const t = (b.textContent || "").trim();
          return t.length < 20 && /^(play|смотреть|воспроизвести|▶|⏵)/i.test(t);
        });
        if (any) { any.click(); return "нажата кнопка Play"; }
        return "не нашлось ни видео, ни кнопки";
      },
    });
    return (r && r.result) || "?";
  } catch (e) { return "не удалось (" + e.message + ")"; }
}

async function waitForStream(tabId, ms) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try {
      const { items } = await chrome.runtime.sendMessage({ type: "getPlaylists", tabId });
      const ms8 = (items || []).filter((e) => e.url.includes("m3u8"));
      // по свежести: вкладка переиспользуется, старые плейлисты могли остаться
      const fresh = ms8.slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
      const m = fresh.find((e) => e.url.includes("master-playlist")) || fresh[0];
      if (m) return m.url;
    } catch (e) { /* гонка сообщений */ }
    await waitMs(2000);
  }
  return null;
}

/* Одна вкладка на ВСЕ видео, а не новая на каждый файл: при 72 видео
   это 72 вкладки и 72 перезагрузки. Вкладку переиспользуем: чистим
   пойманные плейлисты (иначе возьмём поток от ПРЕДЫДУЩЕГО видео) и
   переходим на следующий файл. */
let videoTabId = null;

async function ensureVideoTab() {
  if (videoTabId !== null) {
    try {
      const t = await chrome.tabs.get(videoTabId);
      if (t) return videoTabId;
    } catch (e) { /* вкладку закрыли — заведём новую */ }
    videoTabId = null;
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: false });
  videoTabId = tab.id;
  return videoTabId;
}

async function closeVideoTab() {
  if (videoTabId === null) return;
  const id = videoTabId;
  videoTabId = null;
  try { await chrome.tabs.remove(id); } catch (e) { /* уже закрыта */ }
}

/* Видео: поток берём ПРЯМО из HTML страницы файла — плеер не нужен.
   В HTML страницы disk.yandex.ru/d/<id>/<путь> лежит блок "videoStreams":
   все качества (240p…1080p) с готовыми ссылками на плейлисты.
   Проверено 12.11.2026: страница отдаёт его и с Origin расширения,
   и без cookies; плейлисты и сегменты качаются напрямую.

   Это убирает главную беду батча: плеер не запускался, ролики приходилось
   стартовать руками, а кнопка «Play» в фоновой вкладке тем более.
   Старый путь через вкладку остаётся запасным (если в HTML нет потоков). */
async function videoViaPage(filePath, quality, onProg, strictQuality) {
  const url = diskFilePageUrl(batchCtx.pageKey, filePath);
  const t0 = Date.now();
  const info = await fetchVideoStreams(url);
  if (!info || !info.master) return null;
  const dur = info.duration ? ` · длительность ${Math.round(info.duration / 1000)} с` : "";
  const qs = info.variants.map((v) => v.label).join(", ");
  log(`    поток из HTML: ${qs}${dur} [${Math.round((Date.now() - t0) / 1000)} с]`);
  return await hlsToBlob(info.master, quality, onProg, strictQuality);
}

/* Запасной путь: вкладка с видео + автоплей (нужен, если в HTML нет потоков).
   Исторически это был единственный способ — отсюда все сложности с Play. */
async function videoViaTab(filePath, quality, onProg, strictQuality) {
  const enc = filePath.split("/").map(encodeURIComponent).join("/");
  const tabId = await ensureVideoTab();
  // плейлисты предыдущего видео не должны попасть в выборку
  await chrome.runtime.sendMessage({ type: "clearPlaylists", tabId }).catch(() => {});
  await chrome.tabs.update(tabId, { url: `${batchCtx.pageKey}${enc}`, active: false });
  await waitMs(5000);
  const tPlay = Date.now();
  log("    автоплей: " + (await tryAutoPlay(tabId)));
  // Успех автозапуска определяется тем, пойман ли поток: сам play() может быть
  // отменён сайтом (AbortError) и при этом видео играет штатно.
  let master = await waitForStream(tabId, 45000);
  let how = "с первого раза";
  if (!master) {
    await tryAutoPlay(tabId);
    master = await waitForStream(tabId, 30000);
    how = "со второй попытки";
  }
  if (!master) {
    await chrome.tabs.update(tabId, { active: true });
    log("    ⚠ Нажми Play в открывшейся вкладке — жду 120 с…");
    master = await waitForStream(tabId, 120000);
    how = "только вручную";
  }
  if (!master) throw new Error("поток не пойман");
  log(`    поток пойман за ${Math.round((Date.now() - tPlay) / 1000)} с (${how})`);
  return await hlsToBlob(master, quality, onProg, strictQuality);
}

$("btnBatchGo").onclick = async () => {
  if (batchRunning) return;
  const sel = batchFiles.filter((f) => f.checked);
  if (!sel.length) { log("Ничего не выбрано."); return; }
  batchRunning = true;
  const quality = $("batchQ").value;
  const strictQ = quality !== "best"; // не молча менять качество на другое под капотом
  const prog = $("batchProg");
  prog.hidden = false;
  // зеркалим структуру сайта: YaDiskSaver/<имя публикации>/<путь как на сайте>
  const rootSeg = safeName(batchCtx.rootName || batchCtx.pubId);
  const relOf = (f) => [rootSeg, ...f.path.split("/").filter((s) => s !== "").map(safeName)].join("/");
  const conversions = []; // {ts, out} относительно YaDiskSaver/
  let ok = 0, fail = 0, skip = 0;
  batchCancel = false;
  refreshButtons();
  try {
    for (let i = 0; i < sel.length; i++) {
      if (batchCancel) { log("Остановлено по запросу."); break; }
      const f = sel[i];
      const rel = relOf(f);
      const tFile = Date.now();
      log(`[${i + 1}/${sel.length}] ${f.path} (${fmtMB(f.size)})`);
      try {
        if (f.kind === "doc") {
          if (!batchCtx.rootHash) throw new Error("cloud-api не отдал public_key публикации");
          const yaUrl = `ya-disk-public://${batchCtx.rootHash}:${f.path}`;
          // 1) ОРИГИНАЛ: docx/xlsx/pptx Яндекс отдаёт как есть (WOPI) —
          //    файл сохраняется с настоящим расширением, без перерисовки в PDF.
          //    Форматы, где оригинала нет (PDF), запоминаем, чтобы не дёргать
          //    сервер лишний раз на каждом файле.
          const ext = (f.name.match(/\.([A-Za-z0-9]{1,6})$/) || ["", ""])[1].toLowerCase();
          let orig = null;
          if (!origUnsupported.has(ext)) {
            orig = await fetchOriginalFile(yaUrl);
            if (!orig) origUnsupported.add(ext);
          }
          if (orig) {
            await downloadBlob(orig.blob, "YaDiskSaver/" + rel, false);
            log(`    → оригинал ${f.name}, ${fmtMB(orig.bytes)}  [${Math.round((Date.now() - tFile) / 1000)} с]`);
            ok++;
          } else {
            // 2) формат без оригинала (PDF) — собираем из страниц просмотрщика
            const { blob, pages } = await docToPdfBlob(yaUrl, f.name, (a, b) => {
              prog.value = Math.round(((i + a / b) / sel.length) * 100);
            });
            // имя как у оригинала: "Ревизия.docx" -> "Ревизия.pdf", без ".viewer"
            await downloadBlob(blob, "YaDiskSaver/" + rel.replace(/\.\w+$/, "") + ".pdf", false);
            log(`    → PDF (${pages} стр)  [${Math.round((Date.now() - tFile) / 1000)} с]`);
            ok++;
          }
        } else if (f.kind === "video") {
          // Сначала — поток прямо из HTML страницы файла (плеер не нужен).
          // Если там нет потоков — запасной путь через вкладку с автоплеем.
          let res = await videoViaPage(f.path, quality, (a, b) => {
            prog.value = Math.round(((i + a / b) / sel.length) * 100);
          }, strictQ);
          if (!res) {
            log("    в HTML потоков нет — открываю вкладку с видео (запасной путь)");
            res = await videoViaTab(f.path, quality, (a, b) => {
              prog.value = Math.round(((i + a / b) / sel.length) * 100);
            }, strictQ);
          }
          const { blob, label, bytes, segments } = res;
          const base = rel.replace(/\.\w+$/, "");
          const tsRel = `${base}.${safeName(label)}.ts`;
          await downloadBlob(blob, "YaDiskSaver/" + tsRel, false);
          conversions.push({ ts: tsRel, out: rel }); // out — с родным расширением (.MOV/.MP4)
          log(`    → TS ${label}, ${segments} сегм., ${fmtMB(bytes)}  [${Math.round((Date.now() - tFile) / 1000)} с]`);
          ok++;
        } else { log("    пропуск (недоступен при запрете скачивания)"); skip++; }
      } catch (e) {
        fail++;
        log("    ОШИБКА: " + e.message);
      }
      prog.value = Math.round(((i + 1) / sel.length) * 100);
    }
    if (conversions.length) {
      // Готовый convert.bat: ремукс .ts -> родной контейнер без перекодировки.
      // Кодировка UTF-8 БЕЗ BOM: cmd.exe не понимает BOM и падает на первой
      // же строке, а chcp 65001 переключает кодовую страницу на UTF-8.
      const lines = ["@echo off", "chcp 65001 >nul", "cd /d \"%~dp0\"",
        "where ffmpeg >nul 2>nul || (echo Нужен ffmpeg: https://www.gyan.dev/ffmpeg/builds/ ^(положи ffmpeg.exe рядом или добавь в PATH^) & pause & exit /b 1)"];
      for (const c of conversions) lines.push(`ffmpeg -y -i "${c.ts}" -c copy "${c.out}"`);
      lines.push("echo Готово.", "pause");
      // MIME обязан быть application/x-bat: при text/plain Chrome сам
      // дописывает .txt к имени, и получается «...-video.txt».
      const blob = new Blob([lines.join("\r\n") + "\r\n"], { type: "application/x-bat" });
      const batName = "YaDiskSaver/" + rootSeg + "-convert-to-video.bat";
      await downloadBlob(blob, batName, false);
      log(`BAT: ${batName} — запусти его двойным щелчком, .ts превратятся в .MOV/.MP4 как на сайте (нужен ffmpeg, без перекодировки).`);
    }
  } finally {
    await closeVideoTab();   // вкладка-перевозчик больше не нужна
    batchRunning = false;
    prog.hidden = true;
    refreshButtons();
  }
  log(`ИТОГ: ok=${ok} fail=${fail} skip=${skip}. Аудио .m4a недоступны в принципе — только через владельца.`);
};
